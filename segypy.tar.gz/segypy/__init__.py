from .segypy import *
